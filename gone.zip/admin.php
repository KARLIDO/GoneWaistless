<?php
session_start();
require_once 'includes/config.php';
require_once 'includes/auth_functions.php';

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
// Error handling
set_error_handler(function($errno, $errstr, $errfile, $errline) {
    error_log("Error [$errno] $errstr in $errfile on line $errline");
    return true;
});
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
// Constants for file paths
define('ASSETS_URL', 'assets/products/');
define('PRODUCT_UPLOAD_DIR', realpath(dirname(__FILE__) . '/../assets/products/'));
define('PRODUCT_UPLOAD_URL', 'assets/products/');

try {
    // Check if config files exist
    if (!file_exists('includes/config.php') || !file_exists('includes/auth_functions.php')) {
        throw new Exception("Configuration files are missing");
    }

    // Database connection test
    $pdo->query("SELECT 1");

    // Admin check
    if (!file_exists('includes/auth_functions.php')) {
    die("Error: Authentication functions file is missing");
    }

    require_once 'includes/auth_functions.php';

    // Now this should work
    if (!isAdmin()) {
        $_SESSION['login_redirect'] = 'admin/admin.php';
        header("Location: ../login.php?reason=admin_access");
        exit;
    }

    // Handle form submissions
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $errors = [];
    
    // Category operations
        if (isset($_POST['add_category'])) {
            handleAddCategory($pdo);
        } elseif (isset($_POST['update_category'])) {
            handleUpdateCategory($pdo);
        } elseif (isset($_POST['add_product'])) {
            handleAddProduct($pdo);
        } elseif (isset($_POST['update_product'])) {
            handleUpdateProduct($pdo);
        }elseif (isset($_GET['delete_user'])) {
            handleDeleteUser($pdo, $_GET['delete_user']);
        }
    }

    // Handle delete actions
    if (isset($_GET['delete_product'])) {
        handleDeleteProduct($pdo, $_GET['delete_product']);
    } elseif (isset($_GET['delete'])) {
        handleDeleteCategory($pdo, $_GET['delete']);
    }

    // Get current tab
    $current_tab = $_GET['tab'] ?? 'categories';
    $users = [];
    if ($current_tab === 'users') {
        $users = fetchUsers($pdo);
    }

    // Fetch data for display
    $categories = fetchCategories($pdo);
    $products = ($current_tab === 'products') ? fetchProducts($pdo) : [];

} catch (Exception $e) {
    error_log("Uncaught exception: " . $e->getMessage());
    die("A system error occurred. Please try again later.");
}

// ===== HELPER FUNCTIONS ===== //

function handleAddCategory($pdo) {
    global $errors;
    
    $name = trim($_POST['name']);
    $slug = trim($_POST['slug']);
    $description = trim($_POST['description']);
    $is_featured = isset($_POST['is_featured']) ? 1 : 0;
    
    // Validate inputs
    if (empty($name)) $errors[] = "Category name is required";
    if (empty($slug)) $errors[] = "URL slug is required";
    
    if (empty($errors)) {
        $image_path = handleImageUpload('image', 'assets/categories/');
        
        if ($image_path) {
            try {
                $pdo->beginTransaction();
                
                // Insert category
                $stmt = $pdo->prepare("INSERT INTO categories (name, slug, description, is_featured) VALUES (?, ?, ?, ?)");
                $stmt->execute([$name, $slug, $description, $is_featured]);
                $category_id = $pdo->lastInsertId();
                
                // Insert image
                $stmt = $pdo->prepare("INSERT INTO category_images (category_id, image_path, is_primary) VALUES (?, ?, 1)");
                $stmt->execute([$category_id, $image_path]);
                
                $pdo->commit();
                $_SESSION['success'] = "Category added successfully!";
                header("Location: admin.php");
                exit;
            } catch (PDOException $e) {
                $pdo->rollBack();
                $errors[] = "Database error: " . $e->getMessage();
            }
        } else {
            $errors[] = "Image upload failed";
        }
    }
}
function handleUpdateCategory($pdo) {
    global $errors;
    
    $id = $_POST['id'];
    $name = trim($_POST['name']);
    $slug = trim($_POST['slug']);
    $description = trim($_POST['description']);
    $is_featured = isset($_POST['is_featured']) ? 1 : 0;
    
    // Validate inputs
    if (empty($name)) $errors[] = "Category name is required";
    if (empty($slug)) $errors[] = "URL slug is required";
    
    if (empty($errors)) {
        try {
            $pdo->beginTransaction();
            
            // Update category
            $stmt = $pdo->prepare("UPDATE categories SET name = ?, slug = ?, description = ?, is_featured = ? WHERE id = ?");
            $stmt->execute([$name, $slug, $description, $is_featured, $id]);
            
            // Handle image upload if a new one was provided
            if (!empty($_FILES['image']['name'])) {
                $image_path = handleImageUpload('image', 'assets/categories/');
                if ($image_path) {
                    // Update the primary image
                    $stmt = $pdo->prepare("UPDATE category_images SET image_path = ? WHERE category_id = ? AND is_primary = 1");
                    $stmt->execute([$image_path, $id]);
                }
            }
            
            $pdo->commit();
            $_SESSION['success'] = "Category updated successfully!";
            header("Location: admin.php");
            exit;
        } catch (PDOException $e) {
            $pdo->rollBack();
            $errors[] = "Database error: " . $e->getMessage();
        }
    }
}
function handleDeleteCategory($pdo, $id) {
    try {
        $pdo->beginTransaction();
        
        // Delete category images first
        $stmt = $pdo->prepare("DELETE FROM category_images WHERE category_id = ?");
        $stmt->execute([$id]);
        
        // Then delete the category
        $stmt = $pdo->prepare("DELETE FROM categories WHERE id = ?");
        $stmt->execute([$id]);
        
        $pdo->commit();
        $_SESSION['success'] = "Category deleted successfully!";
    } catch (PDOException $e) {
        $pdo->rollBack();
        $_SESSION['error'] = "Error deleting category: " . $e->getMessage();
    }
    
    header("Location: admin.php");
    exit;
}


function handleAddProduct($pdo) {
    global $errors;
    
    $category_id = $_POST['category_id'];
    $name = trim($_POST['name']);
    $slug = trim($_POST['slug']);
    $price = trim($_POST['price']);
    $description = trim($_POST['description']);
    $is_on_sale = isset($_POST['is_on_sale']) ? 1 : 0;
    $sale_price = $is_on_sale ? trim($_POST['sale_price']) : null;
    $colors = $_POST['colors'] ?? [];
    $sizes = $_POST['sizes'] ?? [];
    $quantities = $_POST['quantities'] ?? [];
    
    // Validate inputs
    if (empty($name)) $errors[] = "Product name is required";
    if (empty($slug)) $errors[] = "URL slug is required";
    if (!is_numeric($price) || $price <= 0) $errors[] = "Valid price is required";
    if ($is_on_sale && (!is_numeric($sale_price) || $sale_price <= 0)) {
        $errors[] = "Valid sale price is required when on sale";
    }
    if (empty($_FILES['main_image']['name'])) $errors[] = "Main image is required";
    
    if (empty($errors)) {
        try {
            $pdo->beginTransaction();
            
            // Insert product
            $stmt = $pdo->prepare("INSERT INTO products (category_id, name, slug, price, description, is_on_sale, sale_price) VALUES (?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute([$category_id, $name, $slug, $price, $description, $is_on_sale, $sale_price]);
            $product_id = $pdo->lastInsertId();
            
            // Process main image
            $main_image_path = handleImageUpload('main_image', PRODUCT_UPLOAD_DIR);
            if (!$main_image_path) {
                throw new Exception("Main image upload failed");
            }
            
            $stmt = $pdo->prepare("INSERT INTO product_images (product_id, image_path, is_primary) VALUES (?, ?, 1)");
            $stmt->execute([$product_id, $main_image_path]);
            
            // Process additional images
            if (!empty($_FILES['additional_images']['name'][0])) {
                foreach ($_FILES['additional_images']['tmp_name'] as $key => $tmp_name) {
                    if ($_FILES['additional_images']['error'][$key] === UPLOAD_ERR_OK) {
                        $additional_image_path = handleImageUpload('additional_images', PRODUCT_UPLOAD_DIR, $key);
                        if ($additional_image_path) {
                            $stmt = $pdo->prepare("INSERT INTO product_images (product_id, image_path, is_primary) VALUES (?, ?, 0)");
                            $stmt->execute([$product_id, $additional_image_path]);
                        }
                    }
                }
            }
            
            // Insert variants
            $total_quantity = 0;
            foreach ($colors as $color_key => $color) {
                foreach ($sizes as $size_key => $size) {
                    $quantity = (int)$quantities[$color_key][$size_key];
                    if ($quantity > 0) {
                        $stmt = $pdo->prepare("INSERT INTO product_variants (product_id, color, size, quantity) VALUES (?, ?, ?, ?)");
                        $stmt->execute([$product_id, $color, $size, $quantity]);
                        $total_quantity += $quantity;
                    }
                }
            }
            
            // Update total quantity
            $stmt = $pdo->prepare("UPDATE products SET quantity = ? WHERE id = ?");
            $stmt->execute([$total_quantity, $product_id]);
            
            $pdo->commit();
            $_SESSION['success'] = "Product added successfully!";
            header("Location: admin.php?tab=products");
            exit;
        } catch (Exception $e) {
            $pdo->rollBack();
            $errors[] = "Error: " . $e->getMessage();
        }
    }
}
function handleUpdateProduct($pdo) {
    global $errors;
    
    $product_id = $_POST['id'];
    $category_id = $_POST['category_id'];
    $name = trim($_POST['name']);
    $slug = trim($_POST['slug']);
    $price = trim($_POST['price']);
    $description = trim($_POST['description']);
    $is_on_sale = isset($_POST['is_on_sale']) ? 1 : 0;
    $sale_price = $is_on_sale ? trim($_POST['sale_price']) : null;
    $colors = $_POST['colors'] ?? [];
    $sizes = $_POST['sizes'] ?? [];
    $quantities = $_POST['quantities'] ?? [];
    
    // Validate inputs
    if (empty($name)) $errors[] = "Product name is required";
    if (empty($slug)) $errors[] = "URL slug is required";
    if (!is_numeric($price) || $price <= 0) $errors[] = "Valid price is required";
    if ($is_on_sale && (!is_numeric($sale_price) || $sale_price <= 0)) {
        $errors[] = "Valid sale price is required when on sale";
    }
    
    if (empty($errors)) {
        try {
            $pdo->beginTransaction();
            
            // Update product
            $stmt = $pdo->prepare("UPDATE products SET 
                category_id = ?, 
                name = ?, 
                slug = ?, 
                price = ?, 
                description = ?, 
                is_on_sale = ?, 
                sale_price = ? 
                WHERE id = ?");
            $stmt->execute([
                $category_id, 
                $name, 
                $slug, 
                $price, 
                $description, 
                $is_on_sale, 
                $sale_price, 
                $product_id
            ]);
            
            // Process main image if a new one was uploaded
            if (!empty($_FILES['main_image']['name'])) {
                $main_image_path = handleImageUpload('main_image', PRODUCT_UPLOAD_DIR);
                if ($main_image_path) {
                    // Update the primary image
                    $stmt = $pdo->prepare("UPDATE product_images 
                        SET image_path = ? 
                        WHERE product_id = ? AND is_primary = 1");
                    $stmt->execute([$main_image_path, $product_id]);
                }
            }
            
            // Process additional images
            if (!empty($_FILES['additional_images']['name'][0])) {
                foreach ($_FILES['additional_images']['tmp_name'] as $key => $tmp_name) {
                    if ($_FILES['additional_images']['error'][$key] === UPLOAD_ERR_OK) {
                        $additional_image_path = handleImageUpload('additional_images', PRODUCT_UPLOAD_DIR, $key);
                        if ($additional_image_path) {
                            $stmt = $pdo->prepare("INSERT INTO product_images 
                                (product_id, image_path, is_primary) 
                                VALUES (?, ?, 0)");
                            $stmt->execute([$product_id, $additional_image_path]);
                        }
                    }
                }
            }
            
            // Delete existing variants
            $stmt = $pdo->prepare("DELETE FROM product_variants WHERE product_id = ?");
            $stmt->execute([$product_id]);
            
            // Insert updated variants
            $total_quantity = 0;
            foreach ($colors as $color_key => $color) {
                foreach ($sizes as $size_key => $size) {
                    $quantity = (int)$quantities[$color_key][$size_key];
                    if ($quantity > 0) {
                        $stmt = $pdo->prepare("INSERT INTO product_variants 
                            (product_id, color, size, quantity) 
                            VALUES (?, ?, ?, ?)");
                        $stmt->execute([$product_id, $color, $size, $quantity]);
                        $total_quantity += $quantity;
                    }
                }
            }
            
            // Update total quantity
            $stmt = $pdo->prepare("UPDATE products SET quantity = ? WHERE id = ?");
            $stmt->execute([$total_quantity, $product_id]);
            
            $pdo->commit();
            $_SESSION['success'] = "Product updated successfully!";
            header("Location: admin.php?tab=products");
            exit;
        } catch (Exception $e) {
            $pdo->rollBack();
            $errors[] = "Error updating product: " . $e->getMessage();
        }
    }
}

function handleDeleteProduct($pdo, $id) {
    try {
        $pdo->beginTransaction();
        
        // Delete product images first
        $stmt = $pdo->prepare("DELETE FROM product_images WHERE product_id = ?");
        $stmt->execute([$id]);
        
        // Delete variants
        $stmt = $pdo->prepare("DELETE FROM product_variants WHERE product_id = ?");
        $stmt->execute([$id]);
        
        // Then delete the product
        $stmt = $pdo->prepare("DELETE FROM products WHERE id = ?");
        $stmt->execute([$id]);
        
        $pdo->commit();
        $_SESSION['success'] = "Product deleted successfully!";
    } catch (PDOException $e) {
        $pdo->rollBack();
        $_SESSION['error'] = "Error deleting product: " . $e->getMessage();
    }
    
    header("Location: admin.php?tab=products");
    exit;
}
function handleImageUpload($fieldName, $upload_dir, $index = null) {
    if (!file_exists($upload_dir)) {
        if (!mkdir($upload_dir, 0755, true)) {
            error_log("Failed to create directory: $upload_dir");
            return false;
        }
    }

    $file = $index !== null ? $_FILES[$fieldName]['tmp_name'][$index] : $_FILES[$fieldName]['tmp_name'];
    $error = $index !== null ? $_FILES[$fieldName]['error'][$index] : $_FILES[$fieldName]['error'];
    $name = $index !== null ? $_FILES[$fieldName]['name'][$index] : $_FILES[$fieldName]['name'];

    if ($error === UPLOAD_ERR_OK) {
        $file_ext = pathinfo($name, PATHINFO_EXTENSION);
        $filename = uniqid() . '.' . $file_ext;
        $target_file = $upload_dir . $filename;
        
        if (move_uploaded_file($file, $target_file)) {
            return str_replace(PRODUCT_UPLOAD_DIR, PRODUCT_UPLOAD_URL, $target_file);
        } else {
            error_log("Failed to move uploaded file to: $target_file");
        }
    } else {
        error_log("Upload error [$error] for file: $name");
    }
    
    return false;
}

function fetchCategories($pdo) {
    return $pdo->query("
        SELECT c.*, ci.image_path 
        FROM categories c
        LEFT JOIN category_images ci ON c.id = ci.category_id AND ci.is_primary = 1
        ORDER BY c.name
    ")->fetchAll(PDO::FETCH_ASSOC);
}

function fetchProducts($pdo) {
    return $pdo->query("
        SELECT p.*, c.name as category_name, 
               (SELECT image_path FROM product_images WHERE product_id = p.id AND is_primary = 1 LIMIT 1) as main_image_path,
               (SELECT GROUP_CONCAT(image_path SEPARATOR ',') FROM product_images WHERE product_id = p.id AND is_primary = 0) as additional_images
        FROM products p
        JOIN categories c ON p.category_id = c.id
        ORDER BY p.name
    ")->fetchAll(PDO::FETCH_ASSOC);
}

function fetchUsers($pdo) {
    try {
        // Select all user data except the password
        $stmt = $pdo->prepare("SELECT id, username, email, role, created_at, updated_at FROM users ORDER BY created_at DESC");
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        error_log("Database error fetching users: " . $e->getMessage());
        return [];
    }
}

function handleDeleteUser($pdo, $id) {
    try {
        $pdo->beginTransaction();
        $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
        $stmt->execute([$id]);
        $pdo->commit();
        $_SESSION['success'] = "User deleted successfully!";
    } catch (PDOException $e) {
        $pdo->rollBack();
        $_SESSION['error'] = "Error deleting user: " . $e->getMessage();
    }
    header("Location: admin.php?tab=users");
    exit;
}
// Close the PHP section properly
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Manage Categories</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="shortcut icon" href="assets/logogw.png">
    <style>
        :root {
            --primary-color: #f557ab;
            --secondary-color: #383838;
            --light-color: #f8f9fa;
            --dark-color: #343a40;
            --success-color: #28a745;
            --danger-color: #dc3545;
            --warning-color: #ffc107;
            --info-color: #17a2b8;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f5f5f5;
            color: #333;
        }
        
        .admin-container {
            display: flex;
            min-height: 100vh;
        }
        
        .sidebar {
            width: 250px;
            background-color: var(--secondary-color);
            color: white;
            padding: 20px 0;
            transition: all 0.3s;
            position: fixed; /* Add this */
            height: 100vh; /* Add this */
            overflow-y: auto;
        }
        
        .sidebar-header {
            padding: 0 20px 20px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }
        
        .sidebar-header h3 {
            margin: 0;
            font-size: 1.2rem;
            display: flex;
            align-items: center;
        }
        
        .sidebar-header h3 i {
            margin-right: 10px;
            color: var(--primary-color);
        }
        
        .sidebar-menu {
            padding: 20px 0;
        }
        
        .sidebar-menu ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        
        .sidebar-menu li {
            position: relative;
        }
        
        .sidebar-menu a {
            display: flex;
            align-items: center;
            padding: 12px 20px;
            color: rgba(255, 255, 255, 0.8);
            text-decoration: none;
            transition: all 0.3s;
        }
        
        .sidebar-menu a:hover, .sidebar-menu a.active {
            background-color: rgba(0, 0, 0, 0.2);
            color: white;
        }
        
        .sidebar-menu a i {
            margin-right: 10px;
            width: 20px;
            text-align: center;
        }
        
        .sidebar-menu .active {
            background-color: rgba(0, 0, 0, 0.2);
            color: white;
            border-left: 3px solid var(--primary-color);
        }
        
        .main-content {
            flex: 1;
            padding: 20px;
            overflow-x: auto;
            margin-left: 250px;
        }
        
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 20px;
            background-color: white;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }
        
        .header h1 {
            margin: 0;
            font-size: 1.5rem;
            color: var(--secondary-color);
        }
        
        .user-info {
            display: flex;
            align-items: center;
        }
        
        .user-info img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            margin-right: 10px;
        }
        
        .card {
            background-color: white;
            border-radius: 5px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
            margin-bottom: 20px;
            overflow: hidden;
        }
        
        .card-header {
            padding: 15px 20px;
            border-bottom: 1px solid #eee;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .card-header h2 {
            margin: 0;
            font-size: 1.2rem;
            color: var(--secondary-color);
        }
        
        .card-body {
            padding: 20px;
        }
        
        .table-responsive {
            overflow-x: auto;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
        }
        
        th, td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #eee;
        }
        
        th {
            background-color: #f8f9fa;
            font-weight: 600;
            color: var(--secondary-color);
        }
        
        tr:hover {
            background-color: #f8f9fa;
        }
        
        .btn {
            display: inline-block;
            padding: 8px 12px;
            border-radius: 4px;
            font-size: 14px;
            font-weight: 500;
            text-decoration: none;
            cursor: pointer;
            transition: all 0.3s;
            border: none;
        }
        
        .btn-primary {
            background-color: var(--primary-color);
            color: white;
        }
        
        .btn-primary:hover {
            background-color: #e04d99;
        }
        
        .btn-sm {
            padding: 5px 10px;
            font-size: 12px;
        }
        
        .btn-edit {
            background-color: var(--info-color);
            color: white;
        }
        
        .btn-edit:hover {
            background-color: #138496;
        }
        
        .btn-delete {
            background-color: var(--danger-color);
            color: white;
        }
        
        .btn-delete:hover {
            background-color: #c82333;
        }
        
        .badge {
            display: inline-block;
            padding: 3px 8px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
        }
        
        .badge-success {
            background-color: var(--success-color);
            color: white;
        }
        
        .badge-secondary {
            background-color: #6c757d;
            color: white;
        }
        
        .form-group {
            margin-bottom: 15px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: 500;
        }
        
        .form-control {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 14px;
            transition: border-color 0.3s;
        }
        
        .form-control:focus {
            border-color: var(--primary-color);
            outline: none;
        }
        
        textarea.form-control {
            min-height: 100px;
            resize: vertical;
        }
        
        .checkbox-label {
            display: flex;
            align-items: center;
            cursor: pointer;
        }
        
        .checkbox-label input {
            margin-right: 10px;
        }
        
        .img-thumbnail {
            max-width: 100px;
            height: auto;
            border: 1px solid #ddd;
            border-radius: 4px;
            padding: 5px;
        }
        
        .alert {
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 4px;
        }
        
        .alert-success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        
        .alert-danger {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            z-index: 1000;
            justify-content: center;
            align-items: center;
        }
        
        .modal-content {
            background-color: white;
            border-radius: 5px;
            width: 90%;
            max-width: 600px;
            max-height: 90vh;
            overflow-y: auto;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
        }
        
        .modal-header {
            padding: 15px 20px;
            border-bottom: 1px solid #eee;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .modal-header h3 {
            margin: 0;
            font-size: 1.2rem;
        }
        
        .modal-body {
            padding: 20px;
        }
        
        .modal-footer {
            padding: 15px 20px;
            border-top: 1px solid #eee;
            display: flex;
            justify-content: flex-end;
        }
        
        .close {
            background: none;
            border: none;
            font-size: 20px;
            cursor: pointer;
            color: #6c757d;
        }
        
        @media (max-width: 768px) {
            .admin-container {
                flex-direction: column;
            }
            
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
            }
            
            .main-content {
                padding: 15px;
            }
        }
        @media (max-width: 576px) {
    /* Mobile-specific styles */
    .admin-container {
        flex-direction: column;
    }
    
    .sidebar {
        width: 100%;
        position: fixed;
        top: 0;
        left: -100%;
        height: 100vh;
        z-index: 1000;
        transition: left 0.3s ease;
    }
    
    .sidebar.active {
        left: 0;
    }
    
    .main-content {
        padding: 15px;
        margin-top: 60px; /* Space for menu button */
    }
    
    .header {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        z-index: 900;
        padding: 10px 15px;
    }
    
    .header h1 {
        font-size: 1.2rem;
        margin-left: 40px; /* Space for menu button */
    }
    
    /* Menu button styles */
    .menu-toggle {
        position: fixed;
        top: 10px;
        left: 10px;
        z-index: 1100;
        background: var(--primary-color);
        color: white;
        border: none;
        border-radius: 4px;
        width: 40px;
        height: 40px;
        font-size: 20px;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
    }
    
    /* Overlay when menu is open */
    .sidebar-overlay {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.5);
        z-index: 999;
        display: none;
    }
    
    .sidebar-overlay.active {
        display: block;
    }
    
    /* Adjust modal for small screens */
    .modal-content {
        width: 95%;
    }
    
    /* Adjust table for small screens */
    table {
        font-size: 14px;
    }
    
    th, td {
        padding: 8px 10px;
    }
    
    .btn-sm {
        padding: 3px 6px;
        font-size: 11px;
    }
}
/* Product specific styles */
.size-quantity-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(100px, 1fr));
    gap: 10px;
    margin-top: 10px;
}

.size-quantity-item {
    display: flex;
    flex-direction: column;
}

.variant-group {
    padding: 15px;
    border: 1px solid #eee;
    border-radius: 5px;
    margin-bottom: 15px;
    background-color: #f9f9f9;
}

.variant-group .btn-danger {
    margin-top: 10px;
}

/* Modal scrollable content */
.modal-body {
    max-height: 70vh;
    overflow-y: auto;
}
.modal {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, 0.5);
    z-index: 1000;
    justify-content: center;
    align-items: center;
}

.modal-content {
    background-color: white;
    border-radius: 5px;
    width: 90%;
    max-width: 600px;
    max-height: 90vh;
    overflow-y: auto;
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
}
/* Menu button styles - ensure it's hidden by default */
.menu-toggle {
    display: none; /* Hidden by default */
    position: fixed;
    top: 10px;
    left: 10px;
    z-index: 1100;
    background: var(--primary-color);
    color: white;
    border: none;
    border-radius: 4px;
    width: 40px;
    height: 40px;
    font-size: 20px;
    align-items: center;
    justify-content: center;
    cursor: pointer;
}

/* Only show menu toggle on small screens */
@media (max-width: 768px) {
    .menu-toggle {
        display: flex; /* Show only on small screens */
    }
    
    .sidebar {
        width: 250px;
        left: -250px; /* Hide by default on mobile */
    }
    
    .sidebar.active {
        left: 0;
    }
    
    .main-content {
        margin-left: 0;
        width: 100%;
    }
}

.image-preview-container {
    display: flex;
    flex-wrap: wrap;
    gap: 10px;
    margin-bottom: 15px;
}

.image-preview-item {
    position: relative;
    width: 120px;
    height: 120px;
    border: 1px solid #ddd;
    border-radius: 4px;
    padding: 5px;
    background: white;
    display: flex;
    flex-direction: column;
}

.image-preview-item img {
    max-width: 100%;
    max-height: 80px;
    object-fit: contain;
    margin-bottom: 5px;
}

.image-preview-item button {
    margin-top: auto;
    width: 100%;
    padding: 3px;
    font-size: 12px;
}
/* Add to your existing CSS */
.size-quantity-grid .form-group {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(120px, 1fr));
    gap: 10px;
}

.size-quantity-grid .form-group .size-quantity-item {
    margin-bottom: 10px;
}

.size-quantity-grid .form-group .size-quantity-item div {
    margin-top: 5px;
}

.size-quantity-grid .form-group .size-quantity-item small {
    display: block;
    font-size: 0.8em;
    color: #666;
}

    </style>
</head>
<body>
    <div class="admin-container">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="sidebar-header">
                <h3><i class="fas fa-cog"></i> Admin Dashboard</h3>
            </div>
           <div class="sidebar-menu">
                <ul>
                    <li><a href="#" onclick="switchTab('categories')" class="<?php echo $current_tab === 'categories' ? 'active' : ''; ?>"><i class="fas fa-list"></i> Categories</a></li>
                    <li><a href="#" onclick="switchTab('products')" class="<?php echo $current_tab === 'products' ? 'active' : ''; ?>"><i class="fas fa-box"></i> Products</a></li>
                    <li><a href="../index2.php"><i class="fas fa-sign-out-alt"></i> Back to Site</a></li>
                </ul>
            </div>
        </div>
        
        <!-- Main Content -->
        <div class="main-content">
            <div class="header">
                
                <div class="user-info">
                    <img src="assets/logogw.png" alt="Company Logo">
                    <span><?php echo htmlspecialchars($_SESSION['username'] ?? 'Admin'); ?></span>
                </div>
            </div>
            
            <!-- Success/Error Messages -->
            <?php if (isset($_SESSION['success'])): ?>
                <div class="alert alert-success">
                    <?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
                </div>
            <?php endif; ?>
            
            <?php if (!empty($errors)): ?>
                <div class="alert alert-danger">
                    <?php foreach ($errors as $error): ?>
                        <p><?php echo $error; ?></p>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
            
            <div id="categories-section" style="<?php echo $current_tab !== 'categories' ? 'display: none;' : ''; ?>">
            
            
            <!-- Categories List Card -->
            <div class="card">
                <div class="card-header">
                    <h2><i class="fas fa-list"></i> All Categories</h2>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table>
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Image</th>
                                    <th>Name</th>
                                    <th>Slug</th>
                                    <th>Featured</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($categories as $category): ?>
                                <tr>
                                    <td><?php echo $category['id']; ?></td>
                                    <td>
                                        <?php if (!empty($category['image_path'])): ?>
                                            <img src="../<?php echo htmlspecialchars($category['image_path']); ?>" alt="<?php echo htmlspecialchars($category['name']); ?>" class="img-thumbnail">
                                        <?php else: ?>
                                            <span>No image</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo htmlspecialchars($category['name']); ?></td>
                                    <td><?php echo htmlspecialchars($category['slug']); ?></td>
                                    <td>
                                        <?php if ($category['is_featured']): ?>
                                            <span class="badge badge-success">Yes</span>
                                        <?php else: ?>
                                            <span class="badge badge-secondary">No</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        
                                        <a href="admin.php?delete=<?php echo $category['id']; ?>" class="btn btn-delete btn-sm" onclick="return confirm('Are you sure you want to delete this category?')">
                                            <i class="fas fa-trash"></i> Delete
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    
    
    <!-- Edit Category Modal -->
    <!-- Edit Product Modal -->
<!-- Edit Category Modal -->
<div class="modal" id="editModal">
    <div class="modal-content">
        <div class="modal-header">
            <h3>Edit Category</h3>
            <button class="close" onclick="closeEditModal()">&times;</button>
        </div>
        <div class="modal-body">
            <form id="editCategoryForm" method="POST" enctype="multipart/form-data">
                <input type="hidden" name="id" id="edit_id">
                <input type="hidden" name="update_category" value="1">
                
                <div class="form-group">
                    <label for="edit_name">Category Name</label>
                    <input type="text" id="edit_name" name="name" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label for="edit_slug">URL Slug</label>
                    <input type="text" id="edit_slug" name="slug" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label for="edit_description">Description</label>
                    <textarea id="edit_description" name="description" class="form-control"></textarea>
                </div>
                
                <div class="form-group">
                    <label class="checkbox-label">
                        <input type="checkbox" name="is_featured" id="edit_is_featured">
                        Featured Category
                    </label>
                </div>
                
                <div class="form-group">
                    <label>Current Image</label>
                    <img id="current_image" src="" class="img-thumbnail" style="max-width: 200px; display: none;">
                    <p id="no_image" style="display: none;">No image</p>
                </div>
                
                <div class="form-group">
                    <label for="edit_image">New Image (Leave blank to keep current)</label>
                    <input type="file" id="edit_image" name="image" class="form-control" accept="image/*">
                </div>
            </form>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" onclick="closeEditModal()">Cancel</button>
            <button type="submit" form="editCategoryForm" class="btn btn-primary">Save Changes</button>
        </div>
    </div>
</div>
                                        
   <div id="products-section" style="<?php echo $current_tab !== 'products' ? 'display: none;' : ''; ?>">
    <!-- Add Product Card -->
    

    <!-- Products List Card -->
    <div class="card">
        <div class="card-header">
            <h2><i class="fas fa-list"></i> All Products</h2>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Image</th>
                            <th>Name</th>
                            <th>Category</th>
                            <th>Price</th>
                            <th>Stock</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($products as $product): ?>
                        <tr>
                            <td><?php echo $product['id']; ?></td>
                            <td>
                                <?php if (!empty($product['main_image_path'])): ?>
                                    <img src="<?php echo htmlspecialchars($product['main_image_path']); ?>" 
                                         alt="<?php echo htmlspecialchars($product['name']); ?>" 
                                         class="img-thumbnail" style="max-width: 80px;">
                                <?php else: ?>
                                    <span class="text-muted">No image</span>
                                <?php endif; ?>
                            </td>
                            <td><?php echo htmlspecialchars($product['name']); ?></td>
                            <td><?php echo htmlspecialchars($product['category_name']); ?></td>
                            <td>
                                <?php if ($product['is_on_sale']): ?>
                                    <span class="text-danger">R<?php echo number_format($product['sale_price'], 2); ?></span>
                                    <small class="text-muted d-block"><s>R<?php echo number_format($product['price'], 2); ?></s></small>
                                <?php else: ?>
                                    R<?php echo number_format($product['price'], 2); ?>
                                <?php endif; ?>
                            </td>
                            <td><?php echo $product['quantity']; ?></td>
                            <td>
                                <?php if ($product['quantity'] > 0): ?>
                                    <span class="badge badge-success">In Stock</span>
                                <?php else: ?>
                                    <span class="badge badge-danger">Out of Stock</span>
                                <?php endif; ?>
                                <?php if ($product['is_on_sale']): ?>
                                    <span class="badge badge-warning mt-1 d-block">On Sale</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                
                                <a href="admin.php?delete_product=<?php echo $product['id']; ?>&tab=products" 
                                   class="btn btn-delete btn-sm" 
                                   onclick="return confirm('Are you sure you want to delete this product? All associated data will be permanently removed.')">
                                    <i class="fas fa-trash"></i> Delete
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Add Product Modal (for mobile) -->
<div class="modal" id="addProductModal">
    <div class="modal-content">
        <div class="modal-header">
            <h3>Add New Product</h3>
            <button class="close" onclick="closeAddProductModal()">&times;</button>
        </div>
        <div class="modal-body">
            <!-- Content will be loaded from the main form via JavaScript -->
        </div>
    </div>
</div>

<!-- Edit Product Modal -->
<div class="modal" id="editProductModal">
    <div class="modal-content">
        <div class="modal-header">
            <h3>Edit Product</h3>
            <button class="close" onclick="closeEditProductModal()">&times;</button>
        </div>
        <div class="modal-body">
            <form id="editProductForm" method="POST" enctype="multipart/form-data">
                <input type="hidden" name="id" id="edit_product_id">
                <input type="hidden" name="update_product" value="1">
                
                <div class="form-group">
                    <label for="edit_product_category">Category *</label>
                    <select id="edit_product_category" name="category_id" class="form-control" required>
                        <option value="">Select a category</option>
                        <?php foreach ($categories as $category): ?>
                            <option value="<?php echo $category['id']; ?>"><?php echo htmlspecialchars($category['name']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="edit_product_name">Product Name *</label>
                    <input type="text" id="edit_product_name" name="name" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label for="edit_product_slug">URL Slug *</label>
                    <input type="text" id="edit_product_slug" name="slug" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label for="edit_product_price">Price (ZAR) *</label>
                    <input type="number" id="edit_product_price" name="price" class="form-control" step="0.01" min="0" required>
                </div>
                
                <div class="form-group">
                    <label for="edit_product_description">Description</label>
                    <textarea id="edit_product_description" name="description" class="form-control" rows="4"></textarea>
                </div>
                
                <div class="form-group">
                    <label class="checkbox-label">
                        <input type="checkbox" name="is_on_sale" id="edit_product_is_on_sale" onchange="toggleEditSalePrice()">
                        On Sale
                    </label>
                </div>
                
                <div class="form-group" id="edit_sale_price_group" style="display: none;">
                    <label for="edit_product_sale_price">Sale Price (ZAR) *</label>
                    <input type="number" id="edit_product_sale_price" name="sale_price" class="form-control" step="0.01" min="0">
                </div>
                
                <div class="form-group">
                    <label>Current Main Image</label>
                    <img id="edit_current_main_image" src="" class="img-thumbnail" style="max-width: 200px; display: none;">
                    <p id="edit_no_main_image" style="display: none;">No image</p>
                </div>
                
                <div class="form-group">
                    <label for="edit_product_main_image">New Main Image (Leave blank to keep current)</label>
                    <input type="file" id="edit_product_main_image" name="main_image" class="form-control" accept="image/*">
                </div>
                
                <div class="form-group">
                    <label>Additional Images</label>
                    <div class="image-preview-container">
                        <!-- Example image preview item -->
                        <div class="image-preview-item">
                            <img src="../assets/products/sample.jpg" alt="Product image">
                            <button class="btn btn-danger btn-sm" 
                                    onclick="deleteProductImage('assets/products/sample.jpg', <?php echo $productId; ?>)">
                                <i class="fas fa-trash"></i> Delete
                            </button>
                        </div>
                    </div>
                    <input type="file" id="edit_product_additional_images" 
                           name="additional_images[]" 
                           class="form-control" 
                           accept="image/*" 
                           multiple>
                    <small class="form-text text-muted">
                        Upload new additional images (will be added to existing ones)
                    </small>
                </div>
                
                <h4>Variants</h4>
                <div id="edit_variants_container">
                    <!-- Variants will be populated here by JavaScript -->
                </div>
                <button type="button" class="btn btn-secondary" onclick="addEditVariant()">
                    <i class="fas fa-plus"></i> Add Another Color Variant
                </button>
                
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" onclick="closeEditProductModal()">
                        <i class="fas fa-times"></i> Cancel
                    </button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> Save Changes
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php if ($current_tab === 'users'): ?>
<div id="users" class="tab-pane fade show active">
    <h2>Users Management</h2>
    <?php if (isset($_SESSION['success'])): ?>
        <div class="alert alert-success"><?php echo $_SESSION['success']; unset($_SESSION['success']); ?></div>
    <?php endif; ?>
    <?php if (isset($_SESSION['error'])): ?>
        <div class="alert alert-danger"><?php echo $_SESSION['error']; unset($_SESSION['error']); ?></div>
    <?php endif; ?>
    <div class="table-responsive">
        <table class="table table-bordered table-hover">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Username</th>
                    <th>Email</th>
                    <th>Role</th>
                    <th>Created At</th>
                    <th>Updated At</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($users)): ?>
                    <?php foreach ($users as $user): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($user['id']); ?></td>
                            <td><?php echo htmlspecialchars($user['username']); ?></td>
                            <td><?php echo htmlspecialchars($user['email']); ?></td>
                            <td><?php echo htmlspecialchars($user['role']); ?></td>
                            <td><?php echo htmlspecialchars($user['created_at']); ?></td>
                            <td><?php echo htmlspecialchars($user['updated_at']); ?></td>
                            <td>
                                <a href="admin.php?tab=users&delete_user=<?php echo htmlspecialchars($user['id']); ?>" 
                                   class="btn btn-danger btn-sm" 
                                   onclick="return confirm('Are you sure you want to delete this user?');">Delete</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="7">No users found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php endif; ?>
    <script>
// Global error handler
window.onerror = function(message, source, lineno, colno, error) {
    console.error("Error:", message, "at", source, "line", lineno, "error:", error);
    alert(`An error occurred: ${message}. Please check console for details.`);
    return true; // Prevent default error handling
};

document.addEventListener('DOMContentLoaded', function() {
    // Initialize tabs
    const urlParams = new URLSearchParams(window.location.search);
    const currentTab = urlParams.get('tab') || 'categories';
    switchTab(currentTab);

    // Form initialization
    document.getElementById('name')?.addEventListener('input', generateSlug);
    document.getElementById('product_name')?.addEventListener('input', generateProductSlug);
    
    // Mobile menu setup
    if (window.innerWidth <= 768) {
        initMobileMenu();
    }

    // Admin check
    if (!<?php echo isAdmin() ? 'true' : 'false'; ?>) {
        window.location.href = '../login.php?reason=admin_access';
    }
});

// Mobile menu functions
function initMobileMenu() {
    const menuToggle = document.createElement('button');
    menuToggle.className = 'menu-toggle';
    menuToggle.innerHTML = '<i class="fas fa-bars"></i>';
    menuToggle.onclick = toggleMenu;
    document.body.prepend(menuToggle);
}

function toggleMenu() {
    const sidebar = document.querySelector('.sidebar');
    sidebar.classList.toggle('active');
}

// Tab management
function switchTab(tabName) {
    // Hide all sections
    document.querySelectorAll('[id$="-section"]').forEach(section => {
        section.style.display = 'none';
    });
    
    // Show selected section
    const section = document.getElementById(`${tabName}-section`);
    if (section) section.style.display = 'block';
    
    // Update URL
    history.pushState(null, null, `admin.php?tab=${tabName}`);
    
    // Update active tab in sidebar
    document.querySelectorAll('.sidebar-menu a').forEach(link => {
        link.classList.remove('active');
    });
    const activeLink = document.querySelector(`.sidebar-menu a[onclick*="${tabName}"]`);
    if (activeLink) activeLink.classList.add('active');
}

// Category functions
function generateSlug() {
    const name = this.value;
    const slug = name.toLowerCase()
        .replace(/[^\w\s-]/g, '')
        .replace(/[\s_-]+/g, '-')
        .replace(/^-+|-+$/g, '');
    document.getElementById('slug').value = slug;
}

function generateProductSlug() {
    const name = this.value;
    const slug = name.toLowerCase()
        .replace(/[^\w\s-]/g, '')
        .replace(/[\s_-]+/g, '-')
        .replace(/^-+|-+$/g, '');
    document.getElementById('product_slug').value = slug;
}

function openEditModal(id, name, slug, description, isFeatured, imagePath) {
    document.getElementById('edit_id').value = id;
    document.getElementById('edit_name').value = name;
    document.getElementById('edit_slug').value = slug;
    document.getElementById('edit_description').value = description;
    document.getElementById('edit_is_featured').checked = Boolean(isFeatured);
    
    // Handle image display
    const currentImage = document.getElementById('current_image');
    const noImage = document.getElementById('no_image');
    
    if (imagePath && imagePath.trim() !== '') {
        currentImage.src = '../' + imagePath;
        currentImage.style.display = 'block';
        noImage.style.display = 'none';
    } else {
        currentImage.style.display = 'none';
        noImage.style.display = 'block';
    }
    
    // Show modal
    document.getElementById('editModal').style.display = 'flex';
    document.body.style.overflow = 'hidden';
}

function closeEditModal() {
    document.getElementById('editModal').style.display = 'none';
    document.body.style.overflow = 'auto';
}

// Product functions
function toggleSalePrice() {
    const saleCheckbox = document.getElementById('product_is_on_sale');
    const salePriceGroup = document.getElementById('sale_price_group');
    salePriceGroup.style.display = saleCheckbox.checked ? 'block' : 'none';
}

function toggleEditSalePrice() {
    const saleCheckbox = document.getElementById('edit_product_is_on_sale');
    const salePriceGroup = document.getElementById('edit_sale_price_group');
    salePriceGroup.style.display = saleCheckbox.checked ? 'block' : 'none';
}

function validateProductForm() {
    // Basic validation - expand as needed
    const name = document.getElementById('product_name').value;
    const slug = document.getElementById('product_slug').value;
    const price = document.getElementById('product_price').value;
    const isOnSale = document.getElementById('product_is_on_sale').checked;
    const salePrice = document.getElementById('product_sale_price').value;
    
    if (!name || !slug || !price) {
        alert('Please fill in all required fields');
        return false;
    }
    
    if (isOnSale && (!salePrice || isNaN(salePrice) || parseFloat(salePrice) <= 0)) {
        alert('Please enter a valid sale price');
        return false;
    }
    
    return true;
}

// Variant management
function addVariant() {
    const container = document.getElementById('variants-container');
    const variantCount = container.querySelectorAll('.variant-group').length;
    const categoryId = document.getElementById('product_category').value;
    
    const newVariant = document.createElement('div');
    newVariant.className = 'variant-group';
    newVariant.dataset.index = variantCount;
    
    newVariant.innerHTML = `
        <div class="form-group">
            <label>Color</label>
            <input type="text" name="colors[]" class="form-control" placeholder="e.g., Red, Blue, Black" required>
        </div>
        
        <div class="form-group">
            <label>Sizes & Quantities</label>
            <div class="size-quantity-grid">
                ${generateSizeInputs(categoryId, variantCount)}
            </div>
        </div>
        <button type="button" class="btn btn-danger btn-sm" onclick="removeVariant(this)">Remove</button>
    `;
    
    container.appendChild(newVariant);
}

function generateSizeInputs(categoryId, index, quantities = {}) {
    const isBrasCategory = (categoryId == 7); // Assuming ID 7 is Bras
    
    if (isBrasCategory) {
        const cupSizes = ['AA', 'A', 'B', 'C', 'D', 'DD', 'E', 'F', 'FF'];
        const bandSizes = [34, 36, 38, 40, 42, 44, 46, 48, 50];
        
        let html = '';
        cupSizes.forEach(cup => {
            bandSizes.forEach(band => {
                const size = band + cup;
                const quantity = quantities[size] || 0;
                html += `
                    <div class="size-quantity-item">
                        <label>${size}</label>
                        <input type="number" name="quantities[${index}][${size}]" 
                            class="form-control" min="0" value="${quantity}">
                    </div>
                `;
            });
        });
        return html;
    } else {
        // Standard sizes
        const sizes = ['XS', 'S', 'M', 'L', 'XL', '2XL', '3XL'];
        return sizes.map(size => {
            const quantity = quantities[size] || 0;
            return `
                <div class="size-quantity-item">
                    <label>${size}</label>
                    <input type="number" name="quantities[${index}][${size}]" 
                        class="form-control" min="0" value="${quantity}">
                </div>
            `;
        }).join('');
    }
}

function removeVariant(button) {
    const variantGroup = button.closest('.variant-group');
    if (document.querySelectorAll('.variant-group').length > 1) {
        variantGroup.remove();
    } else {
        alert('You must have at least one variant');
    }
}

// Product modal functions
function openAddProductModal() {
    document.getElementById('addProductModal').style.display = 'flex';
    document.body.style.overflow = 'hidden';
}

function closeAddProductModal() {
    document.getElementById('addProductModal').style.display = 'none';
    document.body.style.overflow = 'auto';
}

function openEditProductModal(id, name, slug, categoryId, price, description, isOnSale, salePrice, mainImagePath, additionalImages) {
    try {
        // Clean up the additional images string
        additionalImages = additionalImages ? additionalImages.replace(/\\/g, '') : '';
        
        // Set basic product info
        document.getElementById('edit_product_id').value = id;
        document.getElementById('edit_product_name').value = name;
        document.getElementById('edit_product_slug').value = slug;
        document.getElementById('edit_product_category').value = categoryId;
        document.getElementById('edit_product_price').value = price;
        document.getElementById('edit_product_description').value = description;
        document.getElementById('edit_product_is_on_sale').checked = Boolean(isOnSale);
        document.getElementById('edit_product_sale_price').value = salePrice || '';
        document.getElementById('edit_sale_price_group').style.display = isOnSale ? 'block' : 'none';
        
        // Set main image
        const currentMainImage = document.getElementById('edit_current_main_image');
        const noMainImage = document.getElementById('edit_no_main_image');
        
        if (mainImagePath && mainImagePath.trim() !== '') {
            currentMainImage.src = '../' + mainImagePath;
            currentMainImage.style.display = 'block';
            noMainImage.style.display = 'none';
        } else {
            currentMainImage.style.display = 'none';
            noMainImage.style.display = 'block';
        }
        
        // Clear existing additional images preview
        const additionalImagesContainer = document.querySelector('#editProductModal .image-preview-container');
        if (additionalImagesContainer) {
            additionalImagesContainer.innerHTML = '';
            
            // Display additional images if they exist
            if (additionalImages && additionalImages.trim() !== '') {
                const imagesArray = additionalImages.split(',');
                
                imagesArray.forEach(imagePath => {
                    imagePath = imagePath.trim();
                    if (imagePath !== '') {
                        const imgDiv = document.createElement('div');
                        imgDiv.className = 'image-preview-item';
                        imgDiv.dataset.imagePath = imagePath; // Store path in data attribute
                        
                        const img = document.createElement('img');
                        img.src = imagePath.startsWith('assets/') ? '../' + imagePath : imagePath;
                        img.alt = 'Additional product image';
                        img.style.maxHeight = '100px';
                        
                        const deleteBtn = document.createElement('button');
                        deleteBtn.className = 'btn btn-danger btn-sm';
                        deleteBtn.innerHTML = '<i class="fas fa-trash"></i>';
                        deleteBtn.onclick = function(e) {
                            e.preventDefault();
                            const imagePath = this.closest('.image-preview-item').dataset.imagePath;
                            deleteProductImage(imagePath, id);
                        };
                        
                        imgDiv.appendChild(img);
                        imgDiv.appendChild(deleteBtn);
                        additionalImagesContainer.appendChild(imgDiv);
                    }
                });
            }
        }
        
        // Load variants
        loadProductVariants(id, categoryId);
        
        // Show modal
        document.getElementById('editProductModal').style.display = 'flex';
        document.body.style.overflow = 'hidden';
        
    } catch (e) {
        console.error("Error opening edit modal:", e);
        alert("An error occurred while opening the edit form. Please check console for details.");
    }
}

function closeEditProductModal() {
    document.getElementById('editProductModal').style.display = 'none';
    document.body.style.overflow = 'auto';
}

// Image handling
function previewImage(input, previewId) {
    const preview = document.getElementById(previewId);
    preview.innerHTML = '';
    
    if (input.files) {
        Array.from(input.files).forEach(file => {
            const reader = new FileReader();
            reader.onload = function(e) {
                const img = document.createElement('img');
                img.src = e.target.result;
                img.style.maxHeight = '100px';
                preview.appendChild(img);
            };
            reader.readAsDataURL(file);
        });
    }
}

async function deleteProductImage(imagePath, productId) {
    if (!confirm('Are you sure you want to delete this image?')) return;

    try {
        // Show loading state
        const deleteBtn = event.target.closest('button');
        const originalHTML = deleteBtn.innerHTML;
        deleteBtn.disabled = true;
        deleteBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';

        const response = await fetch('product_image_handler.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: new URLSearchParams({
                image_path: imagePath,
                product_id: productId,
                action: 'delete_image',
                csrf_token: '<?php echo $_SESSION["csrf_token"] ?? ""; ?>'
            })
        });

        const data = await response.json();

        if (!response.ok || !data.success) {
            throw new Error(data.message || 'Failed to delete image');
        }

        // Remove the image element from the DOM
        const imageItem = deleteBtn.closest('.image-preview-item');
        if (imageItem) {
            imageItem.remove();
        }
        
        // Show success message
        showAlert('Image deleted successfully', 'success');
        
    } catch (error) {
        console.error('Delete error:', error);
        showAlert('Error deleting image: ' + error.message, 'error');
        deleteBtn.innerHTML = originalHTML;
        deleteBtn.disabled = false;
    }
}

// Helper function to show alerts
function showAlert(message, type = 'success') {
    const alertDiv = document.createElement('div');
    alertDiv.className = `alert alert-${type}`;
    alertDiv.textContent = message;
    document.querySelector('.main-content').prepend(alertDiv);
    setTimeout(() => alertDiv.remove(), 5000);
}

// Variant loading for edit
function loadProductVariants(productId, categoryId) {
    const container = document.getElementById('edit_variants_container');
    container.innerHTML = '<p>Loading variants...</p>';
    
    fetch(`get_product_variants.php?product_id=${productId}`)
        .then(response => {
            if (!response.ok) throw new Error('Network response was not ok');
            return response.json();
        })
        .then(data => {
            if (!data.success) throw new Error(data.message || 'Failed to load variants');
            
            container.innerHTML = '';
            
            if (data.variants.length > 0) {
                // Group variants by color
                const variantsByColor = {};
                data.variants.forEach(variant => {
                    if (!variantsByColor[variant.color]) {
                        variantsByColor[variant.color] = {};
                    }
                    variantsByColor[variant.color][variant.size] = variant.quantity;
                });
                
                // Create variant groups
                let variantIndex = 0;
                for (const [color, quantities] of Object.entries(variantsByColor)) {
                    const variantGroup = document.createElement('div');
                    variantGroup.className = 'variant-group';
                    variantGroup.dataset.index = variantIndex;
                    
                    variantGroup.innerHTML = `
                        <div class="form-group">
                            <label>Color</label>
                            <input type="text" name="colors[]" class="form-control" 
                                value="${color}" placeholder="e.g., Red, Blue, Black">
                        </div>
                        
                        <div class="form-group">
                            <label>Sizes & Quantities</label>
                            <div class="size-quantity-grid">
                                ${generateSizeInputs(categoryId, variantIndex, quantities)}
                            </div>
                        </div>
                        <button type="button" class="btn btn-danger btn-sm" onclick="removeVariant(this)">Remove</button>
                    `;
                    
                    container.appendChild(variantGroup);
                    variantIndex++;
                }
            } else {
                addEditVariant();
            }
        })
        .catch(error => {
            console.error('Error loading variants:', error);
            container.innerHTML = `<p class="text-danger">Error loading variants: ${error.message}</p>`;
        });
}

function addEditVariant() {
    const container = document.getElementById('edit_variants_container');
    const variantCount = container.children.length;
    const categoryId = document.getElementById('edit_product_category').value;
    
    const newVariant = document.createElement('div');
    newVariant.className = 'variant-group';
    newVariant.dataset.index = variantCount;
    
    newVariant.innerHTML = `
        <div class="form-group">
            <label>Color</label>
            <input type="text" name="colors[]" class="form-control" placeholder="e.g., Red, Blue, Black">
        </div>
        
        <div class="form-group">
            <label>Sizes & Quantities</label>
            <div class="size-quantity-grid">
                ${generateSizeInputs(categoryId, variantCount)}
            </div>
        </div>
        <button type="button" class="btn btn-danger btn-sm" onclick="removeVariant(this)">Remove</button>
    `;
    
    container.appendChild(newVariant);
}

// Close modals when clicking outside
window.addEventListener('click', function(event) {
    if (event.target.classList.contains('modal')) {
        event.target.style.display = 'none';
        document.body.style.overflow = 'auto';
    }
});

// Initialize image previews
document.getElementById('main_image')?.addEventListener('change', function() {
    previewImage(this, 'main_image_preview');
});

document.getElementById('additional_images')?.addEventListener('change', function() {
    previewImage(this, 'additional_images_preview');
});
</script>
</body>
</html>